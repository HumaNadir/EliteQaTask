# Elite SQA Task Huma Nadir
## To install node modules run this command in vs code
1. npm i
## To install Cypress run this command 
1. npm install cypress 
## To run task follow these commands
1. npx cypress open --e2e --browser chrome
2. You will be redirected to chrome
3. Click on Specs
4. Scroll down to my-own-test 
5. Click on task1 to run
