const { defineConfig } = require("cypress");

module.exports = defineConfig({
  projectId: "823aqq",

  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
  },

  component: {
    devServer: {
      framework: "react",
      bundler: "vite",
    },
  },

  component: {
    devServer: {
      framework: "react",
      bundler: "vite",
    },
  },

  component: {
    devServer: {
      framework: "react",
      bundler: "vite",
    },
  },

  component: {
    devServer: {
      framework: "react",
      bundler: "vite",
    },
  },

  component: {
    devServer: {
      framework: "react",
      bundler: "vite",
    },
  },

  component: {
    devServer: {
      framework: "react",
      bundler: "vite",
    },
  },

  component: {
    devServer: {
      framework: "react",
      bundler: "vite",
    },
  },
});
module.exports = defineConfig({
  projectId: 'sufnqj',
  e2e: {
    specPattern: ["cypress/e2e/*.js", "cypress/e2e/**/*.js"],
  },
});



